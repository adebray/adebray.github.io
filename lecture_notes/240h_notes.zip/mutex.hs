type Mutex = MVar ThreadId

mutex_create :: IO Mutex
mutex_create = newEmptyMVar

mutex_lock, mutex_unlock :: Mutex -> IO ()

mutex_lock mv = myThreadId >>= putMVar mv

mutex_unlock mv = do mytid <- myThreadId
                     lockTid <- tryTakeMVar mv
                     unless (lockTid == Just mytid) $
                         error "mutex_unlock"
