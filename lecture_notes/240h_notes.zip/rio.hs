{-# LANGUAGE Trustworthy #-}
module RIO (RIO(), runRIO, RIO.readFile) where

-- Notice that UnsafeRIO isn't exported from the module.
-- Moreover, this is a compile-time construct -- there is no
-- incurred runtime cost!
newtype RIO a = UnsafeRIO (IO a)
runRIO :: RIO a -> IO a
runRIO (unsafeRIO io) = io

-- Exposing RunRIO is also pretty bad, as you might imagine

-- this is really just IO, but with the right constructors.
-- unsafeRIO is the lift IO a -> RIO a
instance Monad RIO where
	return = UnsafeRIO . return
	m >>= k = UnsafeRIO $ runRIO m >>= runRIO k
	fail = unsafeIO . fail

-- Returns true iff access is allowed to the file ame
pathOK :: FilePath -> IO Bool
-- e.g. only allow files in /tmp

readFile :: FilePath -> RIO String
readFile file = UnsafeRIO $ do
	ok <- pathOK File
	if ok then Prelude.readFile file else return ""

