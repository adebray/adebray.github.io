-- The Lambda Combinator, or "Is Haskell on the front page of Y Combinator?"
-- Arun Debray, September 5, 2013

import Data.List
import System.Process

-- What happens when things like 10 are put in?
numberTest :: Int -> Int
numberTest a = (a + 2) * 44

second :: (a, b, c) -> b
second (_, x, _) = x

-- This is basically wget, but without any sort of error reporting.
downloadURL :: String -> IO String
downloadURL url = do
	results <- readProcessWithExitCode "curl" ["https://news.ycombinator.com/"] ""
	return $ second results

-- Tried to cover some common indicators that a post mentions Haskell. If you can
-- think of any others, let me know!
isHaskellOnTheFrontPage :: String -> Bool
isHaskellOnTheFrontPage webpage = any (\x -> isInfixOf x webpage) ["GHC", "ghc", "ghci", "GHCi", "haskell", "Haskell"]

report :: Bool -> String
report True = "Of course Haskell is on the front page of Y Combinator!"
report False = "Surprisingly, Haskell is not on the front page of Y Combinator."

main = do
	source <- downloadURL "https://news.ycombinator.com/"
	putStrLn $ report $ isHaskellOnTheFrontPage source
