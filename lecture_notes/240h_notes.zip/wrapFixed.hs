wrap :: IO a -> IO a          -- Fixed version of wrap
wrap action = do
  mv <- newEmptyMVar
  -- first we disable interrupts
  mask $ \unmask -> do
	  -- but if we get an exception here, we stick it into the MVar
      tid <- forkIO $ (unmask action >>= putMVar mv) `catch`
                      \e@(SomeException _) -> putMVar mv (throw e)
	  -- here, takeMVar re-enables exceptions, and passes them off to the child thread
	  -- eventually, takeMVar succeeds, and we return its value.
      let loop = takeMVar mv `catch` \e@(SomeException _) ->
                 throwTo tid e >> loop
      loop
