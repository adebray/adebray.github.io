parent = bracket (forkIO child) killThread $
	\_ -> fmap Just action
