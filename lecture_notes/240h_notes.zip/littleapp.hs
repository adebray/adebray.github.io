-- Note: need to call 'cabal install wai warp' to make this work

module Main where

-- Can be simplified by using the OverloadedStrings language extension... but same end result.
import qualified Data.ByteString.Lazy.Char8 as L8
import Network.HTTP.Types
import Network.Wai
import Network.Wai.Handler.Warp (run)

app :: Application
--				   responseLBS uses the response constructor to make a byte string
--				   arguments: status, any arguments, data
app req = return $ responseLBS status200 [] $ L8.pack "Hello, World"

main :: IO ()
main = run 3000 app
