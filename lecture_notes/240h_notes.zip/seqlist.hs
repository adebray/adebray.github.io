seqList :: [a] -> b -> b
seqList [] b     = b
seqList (a:as) b = seq a $ seqList as b
