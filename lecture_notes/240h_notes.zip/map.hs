import Pipes
import Pipes.Prelude (stdinLn, stdoutLn)
import Prelude hiding (map)

map :: Monad m => (a -> b) -> Pipe a b m ()
map f = do
	input <- await
	yield $ f input
	map f

-- Alternate impementation
map f = for cat (yield . f)

main = runEffect $ stdinLn >-> map (++ "!") >-> stdoutLn
