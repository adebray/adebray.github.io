import Data.Maybe (fromJust)
-- fromJust :: Maybe a -> a
-- sends Just a to a, and is an exception on Nothing.

-- here, c is anything of kind * -> *
-- which is figured out automatically discovered by the compiler.
gcast :: (Typeable a, Typeable b) => c a -> Maybe (c b)
gcast c a = mcr
	where mcr = if typeOf (unc ca) == typeOf (unc $ fromJust mcr)
				then Just $ unsafeCoerce ca
				else Nothing
		  unc :: c x -> x
		  unc = undefined
