wrap :: IO a -> IO a
wrap action = do
  mv <- newEmptyMVar
  -- Exception transferred to parent from child, by laziness
  _ <- forkIO $ (action >>= putMVar mv) `catch`
                \e@(SomeException _) -> putMVar mv (throw e)
  takeMVar mv
