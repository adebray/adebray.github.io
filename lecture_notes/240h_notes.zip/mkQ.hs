-- Example
salaryVal :: Typeable a => a -> Double
salaryVal = mkQ 0 $ \(Salary s) -> s -- 0 is the default value.

mkQ :: (Typeable a, Typeable b) => r -> (b -> r) -> a -> r
mkQ defaultVal fn a = case cast fn of Just g  -> g a
									  Nothing -> defaultVal

-- Example: salavyVal () --> 0.0, salaryVal (Salary 7) --> 7.0
