type Account = TVar Double

transfer :: Double -> Account -> Account -> STM ()
transfer amount from to = do
-- Quirk of Haskell: a - b can't be prefixed, since this conflicts with unary negation
-- so subtract a b = b - a
	modifyTVar' from (subtract amount)
	modifyTVar' to (+ amount)

main :: IO ()
main = do
	ac1 <- newTVarIO 10
	ac2 <- newTVarIO 0
	atomically $ transfer 1 ac1 ac2
