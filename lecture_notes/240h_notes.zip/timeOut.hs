data TimedOut = TimedOut UTCTime deriving (Eq, Show, Typeable)
instance Exception TimedOut

timeout :: Int -> IO a -> IO (Maybe a)
timeout usec action = do
  -- Create unique exception val (for nested timeouts)
  -- the unique value is just the current time
  expired <- fmap TimedOut getCurrentTime

  ptid <- myThreadId
  -- Idea: child thread tracks the time, and kills the thread
  -- if time runs out.
  let child = do threadDelay usec
                 throwTo ptid expired
      parent = do ctid <- forkIO child
                  result <- action
                  killThread ctid
                  return $ Just result
  -- uses catchJust in case the parent has to deal with other exceptions
  catchJust (\e -> if e == expired then Just e else Nothing) 
            parent
            (\_ -> return Nothing)
