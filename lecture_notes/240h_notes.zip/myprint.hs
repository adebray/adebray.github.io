myPrint x = putStrLn $ myShow x

*Main> :t myPrint
myPrint :: MyShow a => a -> IO ()
