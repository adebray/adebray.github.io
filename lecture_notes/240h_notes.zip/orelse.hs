transfer2 :: Double -> Account -> Account -> Account -> STM ()
transfer2 amount from1 from2 to =
  atomically $ transferSTM amount from1 to
               `orElse` transferSTM amount from2 to
