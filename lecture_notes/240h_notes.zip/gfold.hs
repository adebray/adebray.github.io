data T a b = C1 a b | C2 deriving (Typeable, Data)

gfoldl k s (C1 a b) = z C1 `k` a `k` b
gfoldl k z C2		= z C2

toConstr (C1 _ _) = ... --encodes constructor number
toConstr C_2	  = ...
gunfold k z c = case constrIndex x of
						1 -> k (k (z C1))
						2 -> z C2
