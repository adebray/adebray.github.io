newtype StateT s m a = StateT { runStateT :: s -> m (a,s) }

instance (Monad m) => Monad (StateT s m) where
	return a = StateT $ \s -> return (a, s)
	m >>= k	= StateT $ \s0 -> do	 -- in monad m
		-- lazy pattern matching: don't check until we need one of the components
		~(a, s1) <- runStateT m s0
		runstateT (k a) s1
		
instance MonadTrans (StateT s) where
	lift ma = StateT $ \s -> do	 -- in monad m
				a <- ma
				return (a,s)

