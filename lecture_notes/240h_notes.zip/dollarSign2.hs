($) :: (a -> b) -> a -> b
f $ x = f x
