-- Standard function: default value, conversion, possible value (to be converted)
maybe :: b -> (a -> b) -> Maybe a -> b
maybe b _ Nothing = b
maybe  _ f (Just a) = f a

-- super duper succinct: if we get nothing, just do nothing (id).
mkT f  = maybe id id $ cast f
