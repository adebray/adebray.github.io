modifyMVar :: MVar a -> (a -> IO (a,b)) -> IO b
modifyMVar m action = mask $ \unmask -> do
  v0 <- takeMVar m -- automatically unmasked while waiting
  -- here, we do want to allow exceptions, but not before or after
  (v, r) <- unmask (action v0) `onException` putMVar m v0
  putMVar m v
  return r
