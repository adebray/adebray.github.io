// map across stuff. With Bash-like syntax!
// though at least it's $0 and not $1.
import Foundation

println([1,2,3].map({$0+1}))
