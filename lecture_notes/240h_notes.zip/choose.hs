prop_encodeOne2 = do
    c <- choose ('\0', '\xFFFF')
    retrn  length (encodeChar c) == 1
