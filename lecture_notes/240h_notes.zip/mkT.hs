mkT :: (Typeable a, Typeable b) => (b -> b) -> a -> a

-- Example
newtype Salary = Salary Double deriving (Show, Data, Typeable)

raiseSalary :: (Typeable a) => a -> a
raiseSalary = mkT $ \(Salary s) -> Salary (s * 1.04)
-- Goal: raiseSalary () --> (), but raiseSalary 7 --> 7.28

-- Example implementation of mkT: uses that (->) is Typeable!
mkT f a = case cast f of Just g		-> g a
						 Nothing	-> a
