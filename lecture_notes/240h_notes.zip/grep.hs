import Pipes
import qualified Pipes.Prelude as Pipes

grep :: Monad m => String -> Pipe String String m r
grep str = Pipes.filter (isInfixOf str)

main = runEffect $ Pipes.stdinLn >-> grep "import" >-> Pipes.stdoutLn
