putStrLn $ "the value of " ++ key ++ " is " ++ show value
