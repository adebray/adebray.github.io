import Pipes
import Pipes.Prelude (stdinLn, stdoutLn)
import Prelude hiding (takeWhile)

takeWhile :: Monad m => (a -> Bool) -> Pipe a a m ()
takeWhile keep = do
	input <- await
	if keep input
		then do
			yield input
			takeWhile keep
		else return ()

main = runEffect $ stdinLn >-> takeWhile (/= "quit") >-> stdoutLn
