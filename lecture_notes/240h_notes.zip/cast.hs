cast :: (Typeable a, Typeable b) => a -> Maybe b
cast a = fix $ \ ~(Just b) if typeOf a == typeOf b
                   		   then Just unsafeCoerce a b
                           else Nothing

