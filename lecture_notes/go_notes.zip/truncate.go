// Lowercase variables are private and unexported
type truncate struct {
	src Source
	length int
}

// Uppercase variables and functions are exported
// This is a method of the truncate type, with no arguments, returning a string
// truncate satisfies the Phrase interface
func (t *truncate) Phrase() string {
	/* Here, 't' is akin to 'self' or 'this' in other languages.
	   It is a Go idiom that the name should have meaning, rather than always
	   being the same idea. Ideally, it should also work just the same as a function
	   that accepts t as its first argument.
	 */
	w := t.src.Phrase()
	if len(w) > t.length {
		w = w[:t.length]
	}
	return w
}

// The language is case-sensitive, so this is different from the type
func Truncate(s Source, length int) Source {
	return &truncate{src: s, length: length} // static initialization, return address
	/* Notice that in C, this would return the address on the stack, which is bad.
	   Yet it works in Go, because it was designed to be legal, and to do something
	   on the heap because it is an exposed pointer.

	   In general, the compiler makes decisions about the stack vs. the heap.
	 */
}
