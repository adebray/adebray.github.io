// Send the phrase to all of the players
winnerc := make(chan *Player)

// Throwing away the index value, so that it's purely a 'for-each' loop
// Note that p is scoped only within the for loop, so it has to be redeclared later.
for _, p := range pp {
	/* Anonymous functions are more readable, but when optimizing for performance
	   you might want to define it statically. The compiler's pretty good at dealing
	   with these sorts of things, though.
	 */
	go func(p *Player) {
	// This goroutine leaks; if this weren't a demo, you would want to close it, as
	//		close(winnerc)
		if err := p.Race(w); err != nil {
		// The Race() isn't guaranteed to halt... so you can set a timeout using another channel.
			log.Fatalf("Error from player %v during rage: %v", p, err)
		}
		// err falls out of scope; it was just within the if statement. Block scope options exist.
		winnerc <- p
	/* Passing p into the function helps prevent race conditions; the p
	   inside the anonymous function is scoped differently. It's slightly
	   confusing, but is a common enough idiom. Sometimes, people have
	   arguments (heh) about it, especially in other languages.
	 */
	}(p)
}

// The first one whose reply is received wins.
p := <-winnerc
