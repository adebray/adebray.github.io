type source interface {
	Phrase() string
}

type Rand struct {
	Chars	string
	Length	int
}

func (r *Rand) Phrase() string {
	if r.Chars == "" {
	// Philosophy: the zero value should be useful
		r.Chars = DefaultRandChars
	}
	n := len(r.Chars)
	var b []byte // a slice. This is basically a variable-length array
	for i := 0; i < r.length; i++ {
		b = append(b, r.Chars[rand.Intn(n)])
	}
	return string(b)
}
