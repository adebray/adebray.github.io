var pp []*Player
playerc := make(chan *Player)

// Listen for players
for i := 0, i < 2; i++ {
	// Spin off two goroutines, and continue operating here.
	// func() is the syntax for an anonymous fucntion
	go func() {
		// Listens for inbound connections, get their name, etc.
		// Lots of blocking and network stuff... but totally sequential.
		p, err := AcceptPlayer(listener)
		if err != nil {
			// This is not terribly robust, but it's a demo.
			log.Fatalf("Failed to accept player: %v", err)
		}
		// Send the player object into the player channel, and then stop
		// Go has closures, so it takes playerc with it.
		playerc <- p
	}()
}

// Wait until we have two players
for i := 0; i < 2; i++ {
	// Wait to receive the player from the channel playerc
	p := <-playerc
	// append to the slice
	pp = append(pp, p)
}
