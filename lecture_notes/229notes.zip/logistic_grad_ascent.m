% Matlab functions are a little bit interesting. The function name must be the
% same as the filename.

function [theta, ll] = logistic_grad_ascent(X,y)

% rows of X are training samples
% rows of Y are corresponding 0/1 values

% output ll: vector of log-likelihood values at each iteration
% ouptut theta: parameters

alpha = 0.0001;

[m,n] = size(X);

max_iters = 500;

% It's necessary to append a column of ones so that there are the correct
% number of parameters, so that there is a nonzero intercept term.
X = [ones(size(X,1),1), X];

theta = zeros(n+1, 1);  % initialize theta
for k = 1:max_iters
  % This requires the file sigmoid.m to be in the same directory.
  % A copy can be found at
  % http://cs229.stanford.edu/section/matlab/sigmoid.m
  hx = sigmoid(X*theta);
  theta = theta + alpha * X' * (y-hx); 
  % log-likelihood
  ll(k) = sum( y .* log(hx) + (1 - y) .* log(1 - hx) );
end
