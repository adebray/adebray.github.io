RstructureSpamDataset <- function(spam) {
    factored.cols <- lapply(spam[,1:48], function(col) {
        factor(col == 0, levels=c(T< F), labels=c("no", "yes"))
    })
    cbind(data.frame(factored.cols), type=spam$type)
}
