Predict <- function(features, p.nonspam, p.spam, nonspam.probs, spam.probs) {
	## Predicts whether the feature vector (with 48 observed variables) represents "spam"
	##	or "nonspam" by choosing argmax P(row | type) * P(type).
	##
	## Args:
	##	 features - vector with 48 values (one per observed variable)
	##	 p.nonspam - P(type = "nonspam")
	##	 p.spam - P(type = "spam")
	##	 nonspam.probs - conditional probabilities of the form P(Xi | type = "nonspam")
	##	 spam.probs - conditional probabilities of the form P(Xi | type = "spam")
	## Returns:
	##	 "spam" or "nonspam"
	p.nonspam <- log(p.nonspam)
	p.spam <- log(p.spam)
	nonspam.probs <- log(nonspam.probs)

	# We can abridge this, because for x, y positive, x > y iff log x > log y.
	nonspam <- p.nonspam + sum((features == "yes") * nonspam.probs[2,]) + sum((features == "no") * nonspam.probs[1,])
	spam <- p.nonspam + sum((features == "yes") * spam.probs[2,]) + sum((features == "no") * spam.probs[1,])
	if (nonspam > spam) return("nonspam")
	else return("spam")
}
