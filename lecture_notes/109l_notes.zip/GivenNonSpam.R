venNonSpam <- function(training) {
	## Computes conditional probabilities of the form P(Xi | type = "nonspam").
	##
	## Args:
	##   training - data frame with training data.
	## Returns:
	##   A matrix with 2 rows and 48 columns, one per observed variable
	##   from the training data frame. The first row gives the conditional
	##   probabilities P(Xi = "no" | type = "nonspam") for each of the 48
	##   observed variables. The second row gives conditional probabilities
	##   P(Xi = "yes" | type = "nonspam"). Note that all columns should sum
	##   to one.
	## Details:
	##   This function uses Laplace smoothing for conditional probabilities.
	##   You can implement Laplace smoothing by imagining, for each of
	##   the 48 columns, that we see two additional datapoints ("no" and "yes").

	## Choose the subset of the data frame which contains only "nonspam"
	## rows, and keep only the first 48 columns.
	subset <- training[training$type == "nonspam", 1:48]

	## Compute, for each of the 48 columns in the subset above, the probability
	## of the value being "no". Remember to use Laplace smoothing
	## (would just be mean(col == "no") otherwise)

	# Good shorthand for filtering part of a list and then counting it.
	pNo <- sapply(subset, function(col) mean(c(col == "no", TRUE, FALSE)))

	return(rbind(no = pNo, yes = 1 - pNo))
}
